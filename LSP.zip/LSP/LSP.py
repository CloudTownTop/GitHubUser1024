import sys
import os
import time
os.system("clear")
os.system("figlet LSP")
print

i=raw_input("@root LSP : ")
if i=="new" :
    new=raw_input()
    if new=="common" :
        
        w=raw_input()
        if w == "beginning" :
            try:
                New_file=open('./Website/Common/Common.LSP','w')
                New_file.write("Beginning>>")
                New_file.write('\n')
                while w!="end":
                    w==raw_input()
                    New_file.write(w)
                    New_file.write('\n')
                    print ('\n')
                New_file.write("End<<")
                New_file.close()
                New_file=open('./Website/Common/Common.LSP','r')
                lines=New_file.readlines()
                line=""
                line_n=0
                #while line!="End<<" :
                #    line=New_file.readline()
                #    line_n=line_n+1
                #    if line_n>2147483647:
                #        print ("File Error ! \n")
                #        while True:
                #line_n=line_n-1
                New_file.close()
                print (lines)
                print ('\n')
                print ("Loading download module... \n")
                time.sleep(5)
                
                print ("Complete the task. \n")
print (" ")